package edu.upc.essi.sushitos.ltigdocstool.document;

/**
 * UnexistantDocument class
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class UnexistantDocument extends Exception {

}
