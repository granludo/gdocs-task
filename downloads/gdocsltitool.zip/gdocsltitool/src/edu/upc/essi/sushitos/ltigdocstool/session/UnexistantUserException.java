package edu.upc.essi.sushitos.ltigdocstool.session;

/**
 * UnexistantUserException class
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class UnexistantUserException extends Exception {

}
