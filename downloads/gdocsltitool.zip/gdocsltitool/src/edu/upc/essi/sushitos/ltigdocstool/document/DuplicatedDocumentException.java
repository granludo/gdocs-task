package edu.upc.essi.sushitos.ltigdocstool.document;

/**
 * DuplicatedDocumentException class
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class DuplicatedDocumentException extends Exception {

}
