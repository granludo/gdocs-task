package edu.upc.essi.sushitos.ltigdocstool.web.forms;

public class GradeForm {

    private String grade;
    private String userId;
    private String docId;
    private String gradeType;

    public void setGrade(String grade) {

        this.grade = grade;
    }

    public String getGrade() {

        return grade;
    }

    public void setUserId(String userId) {

        this.userId = userId;
    }

    public String getUserId() {

        return userId;
    }

    public void setDocId(String docId) {

        this.docId = docId;
    }

    public String getDocId() {

        return docId;
    }

    public void setGradeType(String gradeType) {

        this.gradeType = gradeType;
    }

    public String getGradeType() {

        return gradeType;
    }

}
