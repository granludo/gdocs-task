package edu.upc.essi.sushitos.imsglc.basiclti.extensions.serviceresponses;


public class AttributeNotFoundException extends Exception {

}
