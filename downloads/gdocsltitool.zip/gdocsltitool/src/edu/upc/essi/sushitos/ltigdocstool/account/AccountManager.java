package edu.upc.essi.sushitos.ltigdocstool.account;

public class AccountManager {

    public AccountManager() {

    }

    public String getUserMail() {
        UserService userService = UserServiceFactory.getUserService();
    }
}
