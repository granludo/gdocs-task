package edu.upc.essi.sushitos.ltigdocstool.activity;

/**
 * UnexistantActivityException class
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class UnexistantActivityException extends Exception {

}
