package edu.upc.essi.sushitos.ltigdocstool.imsglc.basiclti.organization;

/**
 * DuplicatedOrganizationException class
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class DuplicatedOrganizationException extends Exception {

}
