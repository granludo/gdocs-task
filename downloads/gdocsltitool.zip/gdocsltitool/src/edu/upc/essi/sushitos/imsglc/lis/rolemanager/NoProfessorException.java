package edu.upc.essi.sushitos.imsglc.lis.rolemanager;

/**
 * NoProfessorException
 *
 * @author ngalanis
 * @author jpiguillem
 */
public class NoProfessorException extends Exception {

}
