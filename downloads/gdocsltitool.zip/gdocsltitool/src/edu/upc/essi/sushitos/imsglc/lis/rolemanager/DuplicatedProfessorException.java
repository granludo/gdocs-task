package edu.upc.essi.sushitos.imsglc.lis.rolemanager;

/**
 * DuplicatedActivityException class
 * 
 * @author ngalanis
 * @author jpiguillem
 * 
 */
public class DuplicatedProfessorException extends Exception {

}
