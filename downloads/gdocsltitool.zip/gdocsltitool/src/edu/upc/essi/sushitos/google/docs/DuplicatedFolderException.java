package edu.upc.essi.sushitos.google.docs;

/**
 * DuplicatedFolderException
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class DuplicatedFolderException extends Exception {

}
