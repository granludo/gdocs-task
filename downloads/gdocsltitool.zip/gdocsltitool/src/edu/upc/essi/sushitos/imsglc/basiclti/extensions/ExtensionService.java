package edu.upc.essi.sushitos.imsglc.basiclti.extensions;

//TODO: Make all services extend this class.
public abstract class ExtensionService {
    
    public static String launch(){
        
        return null;
    }

}
