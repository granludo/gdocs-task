package edu.upc.essi.sushitos.imsglc.basiclti.httpserver;

/**
 * LTIRequestException class
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class LTIRequestException extends Exception {

}
