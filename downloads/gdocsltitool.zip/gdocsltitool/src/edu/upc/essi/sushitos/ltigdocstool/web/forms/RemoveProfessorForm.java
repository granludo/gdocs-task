package edu.upc.essi.sushitos.ltigdocstool.web.forms;

/**
 * RemoveProfessorForm class Spring form for professor removing
 * 
 * @author ngalanis
 * @author jpiguillem
 * 
 */
public class RemoveProfessorForm {
    private String email;

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

}
