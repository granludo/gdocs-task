package edu.upc.essi.sushitos.ltigdocstool.database;

/**
 * NeedUpgradeException class
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class NeedUpgradeException extends Exception {

}
