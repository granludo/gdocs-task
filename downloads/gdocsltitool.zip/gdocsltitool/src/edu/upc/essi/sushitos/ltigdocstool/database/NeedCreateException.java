package edu.upc.essi.sushitos.ltigdocstool.database;

/**
 * NeedCreateException class
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class NeedCreateException extends Exception {

}
