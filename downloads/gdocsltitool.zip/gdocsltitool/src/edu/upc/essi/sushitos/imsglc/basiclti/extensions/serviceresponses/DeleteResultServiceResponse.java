package edu.upc.essi.sushitos.imsglc.basiclti.extensions.serviceresponses;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;


public class DeleteResultServiceResponse extends ServiceResponse {

    public DeleteResultServiceResponse(String message) throws ParserConfigurationException,
            SAXException, IOException {

        super(message);
        // TODO Auto-generated constructor stub
    }
    
    

}
