package edu.upc.essi.sushitos.ltigdocstool.imsglc.basiclti.organization;


/**
 * UnexistantOrganizationException class
 * 
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class UnexistantOrganizationException extends Exception {

}
