package edu.upc.essi.sushitos.ltigdocstool.activity;

/**
 * DuplicatedActivityException class
 * 
 * @author ngalanis
 * @author jpiguillem
 *
 */
public class DuplicatedActivityException extends Exception {

}
